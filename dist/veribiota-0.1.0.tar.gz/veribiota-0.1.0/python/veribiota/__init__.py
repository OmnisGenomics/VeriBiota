from __future__ import annotations

from . import adapter as adapter  # re-export subpackage

__all__ = ["adapter"]

